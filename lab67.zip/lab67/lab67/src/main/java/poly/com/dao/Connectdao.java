package poly.com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Connectdao {

    protected static Connection conn;
   
    public Connectdao()
    {
        try {
            String url = "jdbc:sqlserver://DESKTOP-2SH70AB:1433;databaseName=lab6";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection(url, "sa", "123");
            System.out.println("Kết nối thành công!");
        	} 
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
