package control;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({ "/bai3FormServlet", "/form/ud", "/form/create" })
public class bai3FormServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

      
        Map<String, Object> map = new HashMap<>();
        map.put("fullname", "Nguyễn Hoàng Hải Dương");
        map.put("gender", "true"); 
        map.put("country", "VN");   

        req.setAttribute("user", map);
        req.getRequestDispatcher("/form/form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8"); 
        String uri = req.getRequestURI();

        String fullname = req.getParameter("fullname");
        String gender = req.getParameter("gender");
        String country = req.getParameter("country");

        Map<String, Object> map = new HashMap<>();
        map.put("fullname", fullname);
        map.put("gender", gender);     
        map.put("country", country);

        req.setAttribute("user", map);

        if (uri.contains("/form/create")) {
            req.setAttribute("capnhat", "<p style='color:blue; font-weight:bold'>Tạo mới thành công!</p>");
        } else if (uri.contains("/form/ud")) {
            req.setAttribute("capnhat", "<p style='color:green; font-weight:bold'>Cập nhật thành công!</p>");
        }

        req.getRequestDispatcher("/form/form.jsp").forward(req, resp);
    }
}