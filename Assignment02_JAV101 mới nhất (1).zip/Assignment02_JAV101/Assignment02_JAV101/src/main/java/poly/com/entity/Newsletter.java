package poly.com.entity;

public class Newsletter {
	private String email;
    private Boolean enabled;

    public Newsletter() {
    }

    public Newsletter(String email, Boolean enabled) {
        this.email = email;
        this.enabled = enabled;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }
}
