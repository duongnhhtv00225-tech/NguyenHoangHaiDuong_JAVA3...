package poly.com.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.model.Country;
@WebServlet("/bai1")
public class bai1controller extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	List<Country> list = List.of(new Country("VN", "Việt Nam"),new Country("US", "Mỹ"),new Country("CN", "Trung Quốc"));
	req.setAttribute("countries", list);
	req.getRequestDispatcher("bai1.jsp").forward(req, resp);
}
}
